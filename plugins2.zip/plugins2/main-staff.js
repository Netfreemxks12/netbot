let handler = async (m, { conn, command, usedPrefix }) => {
let staff = `🚩 *EQUIPO DE AYUDANTES*
🍟 *Bot:* ${global.botname}
✨️ *Versión:* ${global.vs}

👑 *Propietario:*

• Diamond
🍟 *Rol:* Propietario
🚩 *Número:* netfree.mx/5351524614
✨️ *GitHub:* https://github.com/Gigachad-Chian

🌸  *Colaboradores:*

• Gigachadon
🍟 *Rol:* Developer
🚩 *Número:* netfree.mx/528711426787

• Steven
🍟 *Rol:* Contribuidor
🚩 *Número:* netfree.mx/593984964830

• Dino
🍟 *Rol:* Editor
🚩 *Número:* netfree.mx/527774603921
`
await conn.sendFile(m.chat, icons, 'Jonathan.jpg', staff.trim(), fkontak, true, {
contextInfo: {
'forwardingScore': 200,
'isForwarded': false,
externalAdReply: {
showAdAttribution: true,
renderLargerThumbnail: false,
title: `🥷 Developers 👑`,
body: `🚩 Staff Oficial`,
mediaType: 1,
sourceUrl: redes,
thumbnailUrl: icono
}}
}, { mentions: m.sender })
m.react(emoji)

}
handler.help = ['staff']
handler.command = ['colaboradores', 'staff']
handler.register = true
handler.tags = ['main']

export default handler
